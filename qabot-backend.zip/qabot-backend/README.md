# QABot Backend

AI-powered QA backend with 3 ML models — billing anomaly detection, discrepancy classification, and release confidence scoring.

---

## Quick Start

```bash
cd qabot-backend

# 1. Create virtual environment
python -m venv venv
source venv/bin/activate        # Mac/Linux
venv\Scripts\activate           # Windows

# 2. Install dependencies
pip install -r requirements.txt

# 3. Copy env file and configure
cp .env.example .env

# 4. Run the server
python -m app.main
```

Server starts at: http://localhost:8000
Swagger docs at:  http://localhost:8000/docs

---

## Project Structure

```
qabot-backend/
├── app/
│   ├── main.py              ← FastAPI app, routers, middleware
│   ├── api/
│   │   ├── webhook.py       ← POST /webhook/run (GitHub Actions trigger)
│   │   ├── runs.py          ← GET /api/runs (test run CRUD)
│   │   ├── bugs.py          ← GET /api/bugs (bug report CRUD)
│   │   ├── billing.py       ← POST /api/billing/analyze (ML billing)
│   │   ├── projects.py      ← project management + dashboard stats
│   │   └── ml.py            ← model status, retrain, feature importance
│   ├── core/
│   │   ├── config.py        ← settings from .env
│   │   ├── database.py      ← async SQLAlchemy + SQLite
│   │   ├── models.py        ← ORM models (Project, TestRun, Bug, BillingRecord)
│   │   └── schemas.py       ← Pydantic request/response schemas
│   ├── ml/
│   │   └── engine.py        ← 3 ML models (IsolationForest, RandomForest, GradientBoosting)
│   └── services/
│       └── runner.py        ← background test pipeline (crawl→test→score→bug)
├── data/
│   └── sample_billing.csv   ← sample data for testing billing endpoint
├── models/                  ← auto-created, stores trained .pkl files
├── .github/workflows/
│   └── qabot.yml            ← GitHub Actions workflow
├── requirements.txt
└── .env.example
```

---

## ML Models

### 1. Billing Anomaly Detector (`IsolationForest`)
- **Purpose:** Detects unusual billing charges
- **Algorithm:** Unsupervised — no labelled data needed
- **Features:** actual_amount, discrepancy_pct, service_encoded, line_item_count, day_of_month
- **Output:** `is_anomaly` (bool) + `anomaly_score` (0-1)

### 2. Discrepancy Classifier (`RandomForest`)
- **Purpose:** Classifies *type* of anomaly
- **Classes:** normal / overcharge / undercharge / spike / duplicate / currency_error
- **Output:** `anomaly_type` string + plain-English `ml_explanation`

### 3. Release Confidence Scorer (`GradientBoosting`)
- **Purpose:** 0-100 score on release readiness
- **Features:** pass_rate, fail_rate, critical_failures, coverage_score, duration_ratio
- **Output:** Integer score shown in dashboard

All models train automatically on synthetic data at first run, then persist as `.pkl` files. Retrain on your own data via `/api/ml/retrain/billing/upload`.

---

## Key Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/webhook/run` | GitHub Actions trigger |
| GET | `/api/runs` | List test runs |
| GET | `/api/runs/{id}/status` | Live run poll |
| GET | `/api/bugs` | List bug reports |
| PATCH | `/api/bugs/{id}` | Resolve/ignore bug |
| POST | `/api/billing/analyze` | ML billing analysis (JSON) |
| POST | `/api/billing/upload-csv` | ML billing analysis (CSV) |
| GET | `/api/billing/summary` | Billing stats by service |
| GET | `/api/projects/{id}/dashboard` | Dashboard stats |
| GET | `/api/ml/status` | ML model health |
| POST | `/api/ml/retrain/billing/upload` | Retrain on real data |

---

## Testing the Billing ML

```bash
# Using the sample CSV
curl -X POST "http://localhost:8000/api/billing/upload-csv?project_id=proj_01" \
  -H "X-QABot-Key: qab_live_demo_k9x2mw4p8n" \
  -F "file=@data/sample_billing.csv"

# Using JSON
curl -X POST "http://localhost:8000/api/billing/analyze" \
  -H "Content-Type: application/json" \
  -H "X-QABot-Key: qab_live_demo_k9x2mw4p8n" \
  -d '{
    "records": [{
      "project_id": "proj_01",
      "service_name": "AWS",
      "billing_period": "2024-05",
      "expected_amount": 1200.00,
      "actual_amount": 2398.00
    }]
  }'
```

---

## Connecting to the Frontend

In your frontend (`src/lib/mock-data.ts`), replace mock data with real API calls:

```typescript
const BASE = "http://localhost:8000";
const KEY  = "qab_live_demo_k9x2mw4p8n";

// Fetch runs
const runs = await fetch(`${BASE}/api/runs`, {
  headers: { "X-QABot-Key": KEY }
}).then(r => r.json());

// Fetch open bugs
const bugs = await fetch(`${BASE}/api/bugs?status=open`, {
  headers: { "X-QABot-Key": KEY }
}).then(r => r.json());

// Analyze billing CSV
const formData = new FormData();
formData.append("file", csvFile);
const result = await fetch(`${BASE}/api/billing/upload-csv?project_id=proj_01`, {
  method: "POST",
  headers: { "X-QABot-Key": KEY },
  body: formData,
}).then(r => r.json());
```
