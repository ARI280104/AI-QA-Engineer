"""
app/core/config.py
──────────────────
Centralised settings loaded from .env via pydantic-settings.
"""
from pydantic_settings import BaseSettings
from pathlib import Path


class Settings(BaseSettings):
    # API
    app_name: str = "QABot Backend"
    app_version: str = "1.0.0"
    debug: bool = True
    host: str = "0.0.0.0"
    port: int = 8000

    # Security
    secret_key: str = "dev-secret-change-in-production-xxxxxxxxxxxxx"
    api_key_header: str = "X-QABot-Key"
    demo_api_key: str = "qab_live_demo_k9x2mw4p8n"

    # Database
    database_url: str = "sqlite+aiosqlite:///./qabot.db"

    # ML
    model_dir: str = "./models"
    billing_model_path: str = "./models/billing_anomaly_model.pkl"
    discrepancy_model_path: str = "./models/discrepancy_model.pkl"

    # CORS
    cors_origins: str = "http://localhost:3000,http://localhost:3001"

    # Notifications
    slack_webhook_url: str = ""
    smtp_host: str = "smtp.gmail.com"
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_pass: str = ""

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

    @property
    def cors_origins_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",")]


settings = Settings()

# Ensure model directory exists
Path(settings.model_dir).mkdir(parents=True, exist_ok=True)
