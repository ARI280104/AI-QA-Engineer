"""
app/core/models.py
──────────────────
Database ORM models for projects, test runs, bugs, and billing records.
"""
from sqlalchemy import Column, String, Integer, Float, Boolean, DateTime, Text, JSON, ForeignKey, Enum
from sqlalchemy.orm import relationship
from datetime import datetime
import enum
from app.core.database import Base


class RunStatus(str, enum.Enum):
    pending  = "pending"
    running  = "running"
    pass_    = "pass"
    fail     = "fail"
    warn     = "warn"
    error    = "error"


class Severity(str, enum.Enum):
    critical = "critical"
    high     = "high"
    medium   = "medium"
    low      = "low"


class BugStatus(str, enum.Enum):
    open     = "open"
    resolved = "resolved"
    ignored  = "ignored"


# ─── Project ─────────────────────────────────────────────────────────────────
class Project(Base):
    __tablename__ = "projects"

    id          = Column(String, primary_key=True)
    name        = Column(String, nullable=False)
    repo_url    = Column(String, nullable=False)
    staging_url = Column(String, nullable=False)
    api_key     = Column(String, nullable=False, unique=True)
    created_at  = Column(DateTime, default=datetime.utcnow)
    is_active   = Column(Boolean, default=True)

    runs  = relationship("TestRun", back_populates="project", cascade="all, delete")
    bills = relationship("BillingRecord", back_populates="project", cascade="all, delete")


# ─── Test Run ─────────────────────────────────────────────────────────────────
class TestRun(Base):
    __tablename__ = "test_runs"

    id              = Column(String, primary_key=True)
    project_id      = Column(String, ForeignKey("projects.id"), nullable=False)
    commit_sha      = Column(String)
    commit_message  = Column(String)
    branch          = Column(String, default="main")
    triggered_at    = Column(DateTime, default=datetime.utcnow)
    completed_at    = Column(DateTime, nullable=True)
    duration_secs   = Column(Integer, default=0)
    status          = Column(String, default=RunStatus.pending)

    # Test counts
    total_tests  = Column(Integer, default=0)
    passed       = Column(Integer, default=0)
    failed       = Column(Integer, default=0)
    warned       = Column(Integer, default=0)

    # ML-computed
    score            = Column(Integer, default=0)   # 0-100 release confidence
    anomaly_detected = Column(Boolean, default=False)
    anomaly_details  = Column(JSON, default=list)

    # Raw results storage
    test_results = Column(JSON, default=list)   # list of individual test outcomes
    coverage_map = Column(JSON, default=dict)   # URL -> test count

    project = relationship("Project", back_populates="runs")
    bugs    = relationship("Bug", back_populates="run", cascade="all, delete")


# ─── Bug Report ───────────────────────────────────────────────────────────────
class Bug(Base):
    __tablename__ = "bugs"

    id          = Column(String, primary_key=True)
    run_id      = Column(String, ForeignKey("test_runs.id"), nullable=False)
    project_id  = Column(String, nullable=False)
    title       = Column(String, nullable=False)
    description = Column(Text)
    severity    = Column(String, default=Severity.medium)
    component   = Column(String)
    steps       = Column(JSON, default=list)   # list of strings
    screenshot  = Column(String, nullable=True)  # file path or URL
    status      = Column(String, default=BugStatus.open)
    created_at  = Column(DateTime, default=datetime.utcnow)
    resolved_at = Column(DateTime, nullable=True)

    # ML confidence score (how sure are we this is a real bug, not a flaky test)
    ml_confidence = Column(Float, default=1.0)

    run = relationship("TestRun", back_populates="bugs")


# ─── Billing Record ───────────────────────────────────────────────────────────
class BillingRecord(Base):
    __tablename__ = "billing_records"

    id               = Column(String, primary_key=True)
    project_id       = Column(String, ForeignKey("projects.id"), nullable=False)
    service_name     = Column(String, nullable=False)   # e.g. "AWS", "GitHub", "CDN"
    account_id       = Column(String)
    billing_period   = Column(String)                   # e.g. "2024-05"
    expected_amount  = Column(Float, nullable=False)
    actual_amount    = Column(Float, nullable=False)
    currency         = Column(String, default="USD")
    line_items       = Column(JSON, default=list)       # detailed breakdown
    created_at       = Column(DateTime, default=datetime.utcnow)

    # ML outputs
    is_anomaly        = Column(Boolean, default=False)
    anomaly_score     = Column(Float, default=0.0)      # 0-1, higher = more anomalous
    anomaly_type      = Column(String, nullable=True)   # "overcharge", "duplicate", "spike", etc.
    discrepancy_amount = Column(Float, default=0.0)     # actual - expected
    ml_explanation    = Column(Text, nullable=True)     # plain-English explanation
    status            = Column(String, default="open")  # open / resolved / disputed

    project = relationship("Project", back_populates="bills")
