"""
app/core/schemas.py
───────────────────
Pydantic v2 schemas — API request/response shapes.
"""
from pydantic import BaseModel, Field, HttpUrl
from typing import Optional, List, Any
from datetime import datetime
from enum import Enum


# ─── Enums ────────────────────────────────────────────────────────────────────
class RunStatus(str, Enum):
    pending = "pending"
    running = "running"
    pass_   = "pass"
    fail    = "fail"
    warn    = "warn"
    error   = "error"


class Severity(str, Enum):
    critical = "critical"
    high     = "high"
    medium   = "medium"
    low      = "low"


class BugStatus(str, Enum):
    open     = "open"
    resolved = "resolved"
    ignored  = "ignored"


# ─── Webhook / Run trigger ────────────────────────────────────────────────────
class WebhookPayload(BaseModel):
    repo: str
    owner: str
    sha: str
    ref: str = "refs/heads/main"
    commit_message: Optional[str] = None
    project_id: Optional[str] = None


class RunTriggerResponse(BaseModel):
    run_id: str
    status: str
    message: str


# ─── Test Results ─────────────────────────────────────────────────────────────
class TestResult(BaseModel):
    test_name: str
    status: str          # pass / fail / warn
    duration_ms: int
    error_message: Optional[str] = None
    screenshot_path: Optional[str] = None
    component: Optional[str] = None


class TestRunOut(BaseModel):
    id: str
    project_id: str
    commit_sha: Optional[str]
    commit_message: Optional[str]
    branch: str
    triggered_at: datetime
    completed_at: Optional[datetime]
    duration_secs: int
    status: str
    total_tests: int
    passed: int
    failed: int
    warned: int
    score: int
    anomaly_detected: bool
    anomaly_details: List[Any]
    test_results: List[Any]

    class Config:
        from_attributes = True


# ─── Bugs ─────────────────────────────────────────────────────────────────────
class BugOut(BaseModel):
    id: str
    run_id: str
    project_id: str
    title: str
    description: Optional[str]
    severity: str
    component: Optional[str]
    steps: List[str]
    screenshot: Optional[str]
    status: str
    created_at: datetime
    ml_confidence: float

    class Config:
        from_attributes = True


class BugUpdate(BaseModel):
    status: BugStatus


# ─── Billing ──────────────────────────────────────────────────────────────────
class BillingLineItem(BaseModel):
    description: str
    quantity: float
    unit_price: float
    total: float


class BillingRecordCreate(BaseModel):
    project_id: str
    service_name: str
    account_id: Optional[str] = None
    billing_period: str                        # "2024-05"
    expected_amount: float
    actual_amount: float
    currency: str = "USD"
    line_items: List[BillingLineItem] = []


class BillingRecordOut(BaseModel):
    id: str
    project_id: str
    service_name: str
    account_id: Optional[str]
    billing_period: str
    expected_amount: float
    actual_amount: float
    currency: str
    line_items: List[Any]
    created_at: datetime
    is_anomaly: bool
    anomaly_score: float
    anomaly_type: Optional[str]
    discrepancy_amount: float
    ml_explanation: Optional[str]
    status: str

    class Config:
        from_attributes = True


class BillingAnalysisRequest(BaseModel):
    """Batch analysis — submit multiple records at once."""
    records: List[BillingRecordCreate]


class BillingAnalysisResponse(BaseModel):
    total_records: int
    anomalies_found: int
    total_discrepancy: float
    results: List[BillingRecordOut]
    summary: str


# ─── Project ──────────────────────────────────────────────────────────────────
class ProjectCreate(BaseModel):
    name: str
    repo_url: str
    staging_url: str


class ProjectOut(BaseModel):
    id: str
    name: str
    repo_url: str
    staging_url: str
    created_at: datetime
    is_active: bool

    class Config:
        from_attributes = True


# ─── Dashboard ────────────────────────────────────────────────────────────────
class DashboardStats(BaseModel):
    total_runs: int
    open_bugs: int
    latest_score: int
    avg_duration_secs: float
    billing_anomalies: int
    total_discrepancy: float
