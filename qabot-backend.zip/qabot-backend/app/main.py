"""
app/main.py
───────────
QABot Backend — FastAPI application entry point.

Endpoints at a glance:
  POST  /webhook/run              ← GitHub Actions calls this on every push
  GET   /api/runs                 ← list test runs
  GET   /api/runs/{id}            ← single run detail
  GET   /api/runs/{id}/status     ← lightweight live poll
  GET   /api/bugs                 ← list bug reports
  PATCH /api/bugs/{id}            ← resolve / ignore a bug
  POST  /api/billing/analyze      ← ML billing analysis (JSON)
  POST  /api/billing/upload-csv   ← ML billing analysis (CSV upload)
  GET   /api/billing              ← list billing records
  GET   /api/billing/summary      ← aggregated billing stats
  GET   /api/projects             ← list projects
  POST  /api/projects             ← create project
  GET   /api/projects/{id}/dashboard ← dashboard stats
  GET   /api/ml/status            ← ML model health
  POST  /api/ml/retrain/billing   ← retrain billing models
  POST  /api/ml/retrain/billing/upload ← retrain on real CSV
  GET   /api/ml/feature-importance     ← RandomForest feature importances
  GET   /health                   ← health check
  GET   /docs                     ← Swagger UI
"""

import logging
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.core.config import settings
from app.core.database import init_db
from app.api import webhook, runs, bugs, billing, projects, ml

# ─── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)


# ─── Lifespan (startup / shutdown) ────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialise DB and pre-load ML models on startup."""
    logger.info("QABot Backend starting up...")
    await init_db()
    logger.info("Database initialised.")

    # Pre-load ML models (trains on first run, loads from disk thereafter)
    from app.ml.engine import get_anomaly_detector, get_discrepancy_classifier, get_confidence_scorer
    get_anomaly_detector()
    get_discrepancy_classifier()
    get_confidence_scorer()
    logger.info("ML models ready.")

    yield   # App is running

    logger.info("QABot Backend shutting down.")


# ─── App ──────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="QABot Backend",
    version=settings.app_version,
    description=(
        "AI-powered QA backend with ML billing anomaly detection, "
        "automated test running, and plain-English bug reporting."
    ),
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

# ─── CORS ─────────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─── Request timing middleware ─────────────────────────────────────────────────
@app.middleware("http")
async def add_process_time(request: Request, call_next):
    start = time.perf_counter()
    response = await call_next(request)
    duration = round((time.perf_counter() - start) * 1000, 2)
    response.headers["X-Process-Time-Ms"] = str(duration)
    return response


# ─── Global error handler ─────────────────────────────────────────────────────
@app.exception_handler(Exception)
async def generic_error_handler(request: Request, exc: Exception):
    logger.exception(f"Unhandled error: {exc}")
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error. Check server logs."},
    )


# ─── Routers ──────────────────────────────────────────────────────────────────
app.include_router(webhook.router)
app.include_router(runs.router)
app.include_router(bugs.router)
app.include_router(billing.router)
app.include_router(projects.router)
app.include_router(ml.router)


# ─── Health check ─────────────────────────────────────────────────────────────
@app.get("/health", tags=["Health"])
async def health():
    return {
        "status":  "ok",
        "version": settings.app_version,
        "app":     settings.app_name,
    }


# ─── Run directly ─────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.host,
        port=settings.port,
        reload=settings.debug,
        log_level="info",
    )
