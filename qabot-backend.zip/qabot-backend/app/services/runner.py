"""
app/services/runner.py
──────────────────────
Background service that simulates the full QA pipeline:
  1. Crawl staging URL (placeholder — swap in real Playwright)
  2. Generate test cases (placeholder — swap in real LLM call)
  3. Run tests (placeholder — swap in real Playwright runner)
  4. Score run with ML
  5. Generate bug reports
  6. Persist everything to DB
"""
import asyncio
import uuid
import logging
import random
from datetime import datetime

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.database import AsyncSessionLocal
from app.core.models import TestRun, Bug, Project
from app.ml.engine import get_confidence_scorer

logger = logging.getLogger(__name__)

# Sample test names that represent real QA scenarios
SAMPLE_TESTS = [
    ("auth.login_with_valid_credentials",      "AuthController"),
    ("auth.login_with_invalid_password",        "AuthController"),
    ("auth.logout_clears_session",              "AuthController"),
    ("auth.password_reset_sends_email",         "AuthController"),
    ("checkout.add_single_item",                "CheckoutButton"),
    ("checkout.add_multiple_items",             "CheckoutButton"),
    ("checkout.proceed_with_full_cart",         "CheckoutButton"),
    ("checkout.payment_stripe_success",         "PaymentGateway"),
    ("checkout.payment_stripe_decline",         "PaymentGateway"),
    ("profile.update_avatar",                   "UserAvatar"),
    ("profile.update_email",                    "UserSettings"),
    ("profile.change_password",                 "UserSettings"),
    ("dashboard.loads_without_error",           "Dashboard"),
    ("dashboard.recent_activity_renders",       "Dashboard"),
    ("nav.sidebar_links_work",                  "Navigation"),
    ("nav.mobile_menu_toggles",                 "Navigation"),
    ("api.get_user_returns_200",                "UserAPI"),
    ("api.post_resource_validates_input",       "ResourceAPI"),
    ("api.delete_requires_auth",                "ResourceAPI"),
    ("forms.required_fields_validated",         "FormValidator"),
    ("forms.email_format_validated",            "FormValidator"),
    ("forms.submit_shows_success_message",      "FormValidator"),
    ("billing.invoice_renders",                 "BillingUI"),
    ("billing.download_pdf_works",              "BillingUI"),
    ("search.returns_relevant_results",         "SearchEngine"),
    ("search.empty_query_handled",              "SearchEngine"),
    ("pagination.next_page_loads",              "Pagination"),
    ("pagination.page_count_correct",           "Pagination"),
    ("404.unknown_route_shows_error",           "ErrorHandler"),
    ("500.server_error_shows_friendly_message", "ErrorHandler"),
]

BUG_TEMPLATES = [
    {
        "title":    "Checkout button unresponsive when cart has more than 3 items",
        "desc":     "When a user adds more than 3 items to the cart and clicks 'Proceed to Checkout', nothing happens. The button appears active but the click event does not fire.",
        "severity": "critical",
        "steps":    ["Add 4+ items to cart", "Navigate to /cart", "Click 'Proceed to Checkout'", "Observe: no navigation, no error"],
        "component":"CheckoutButton",
    },
    {
        "title":    "Password reset email not delivered on staging",
        "desc":     "Clicking 'Send reset link' returns HTTP 200 but no email is delivered. The endpoint silently fails when SMTP credentials are missing in the environment.",
        "severity": "high",
        "steps":    ["Go to /forgot-password", "Enter a registered email", "Click 'Send reset link'", "Check inbox — email never arrives"],
        "component":"AuthController",
    },
    {
        "title":    "User avatar does not update immediately after upload",
        "desc":     "After uploading a new profile picture, the old avatar persists in the nav bar until a full page reload. Likely a stale React state / cache invalidation issue.",
        "severity": "medium",
        "steps":    ["Go to /settings/profile", "Upload a new image", "Observe nav bar — old avatar still shown", "Hard refresh: new avatar appears"],
        "component":"UserAvatar",
    },
    {
        "title":    "Mobile menu does not close after navigation",
        "desc":     "On viewport < 768px, tapping a sidebar link navigates correctly but the mobile menu overlay stays open. Requires manual close tap.",
        "severity": "low",
        "steps":    ["Resize browser to < 768px", "Open mobile menu", "Tap any nav link", "Observe: menu stays open"],
        "component":"Navigation",
    },
    {
        "title":    "Search returns 0 results for valid query on empty index",
        "desc":     "If the search index is not yet populated (fresh deployment), all queries return 0 results with no indication to the user that indexing is in progress.",
        "severity": "medium",
        "steps":    ["Deploy fresh instance", "Navigate to /search", "Type any valid query", "Observe: '0 results' with no context"],
        "component":"SearchEngine",
    },
]


async def run_tests_background(run_id: str, project_id: str, staging_url: str):
    """
    Full async test pipeline — runs in background after webhook trigger.
    Replace the simulated sections with real Playwright + LLM calls.
    """
    async with AsyncSessionLocal() as db:
        try:
            logger.info(f"[{run_id}] Starting test pipeline for {staging_url}")
            start_time = datetime.utcnow()

            # ── Step 1: Crawl ─────────────────────────────────────────────────
            await asyncio.sleep(1.5)   # ← replace with: crawl_staging_url(staging_url)
            crawled_routes = [t[0] for t in SAMPLE_TESTS]
            coverage_map = {r: True for r in crawled_routes}
            logger.info(f"[{run_id}] Crawled {len(crawled_routes)} routes")

            # ── Step 2: Generate tests ────────────────────────────────────────
            await asyncio.sleep(2.0)   # ← replace with: generate_tests_via_llm(crawled_routes)
            logger.info(f"[{run_id}] Generated {len(SAMPLE_TESTS)} test cases")

            # ── Step 3: Run tests ─────────────────────────────────────────────
            await asyncio.sleep(3.0)   # ← replace with: run_playwright(generated_tests)

            # Simulate realistic pass/fail/warn distribution
            results = []
            failing_tests = random.sample(SAMPLE_TESTS, k=random.randint(0, 3))
            warning_tests = random.sample(
                [t for t in SAMPLE_TESTS if t not in failing_tests],
                k=random.randint(0, 4)
            )

            for name, component in SAMPLE_TESTS:
                if (name, component) in failing_tests:
                    status = "fail"
                    error  = f"AssertionError: Expected element '{component}' to be visible"
                elif (name, component) in warning_tests:
                    status = "warn"
                    error  = "Performance: response time > 2000ms"
                else:
                    status = "pass"
                    error  = None
                results.append({
                    "test_name":   name,
                    "status":      status,
                    "duration_ms": random.randint(80, 3500),
                    "error_message": error,
                    "component":   component,
                })

            passed = sum(1 for r in results if r["status"] == "pass")
            failed = sum(1 for r in results if r["status"] == "fail")
            warned = sum(1 for r in results if r["status"] == "warn")
            total  = len(results)

            # ── Step 4: ML Confidence Score ───────────────────────────────────
            scorer = get_confidence_scorer()
            critical_failures = sum(
                1 for r in results
                if r["status"] == "fail" and "auth" in r["test_name"]
            )
            score = scorer.score(
                passed=passed, failed=failed, warned=warned, total=total,
                critical_failures=critical_failures,
                coverage_score=len(crawled_routes) / 30,
                duration_ratio=1.0,
                historical_pass_rate=0.88,
            )
            logger.info(f"[{run_id}] ML score: {score}/100")

            # ── Step 5: Generate bug reports for failed tests ─────────────────
            bugs_created = []
            for i, r in enumerate(results):
                if r["status"] == "fail":
                    # Find matching bug template or create generic one
                    template = next(
                        (t for t in BUG_TEMPLATES if t["component"] == r["component"]),
                        {
                            "title":    f"{r['component']}: {r['test_name'].replace('_', ' ')} failed",
                            "desc":     r.get("error_message") or "Test failed — see screenshot for details.",
                            "severity": "high" if critical_failures > 0 else "medium",
                            "steps":    ["Run the failing test", "Observe the error output"],
                            "component": r["component"],
                        }
                    )
                    bug = Bug(
                        id=f"bug_{uuid.uuid4().hex[:8]}",
                        run_id=run_id,
                        project_id=project_id,
                        title=template["title"],
                        description=template["desc"],
                        severity=template["severity"],
                        component=template["component"],
                        steps=template["steps"],
                        status="open",
                        ml_confidence=round(random.uniform(0.82, 0.99), 2),
                        created_at=datetime.utcnow(),
                    )
                    db.add(bug)
                    bugs_created.append(bug)

            # ── Step 6: Persist run results ───────────────────────────────────
            duration = int((datetime.utcnow() - start_time).total_seconds())
            result_obj = await db.execute(select(TestRun).where(TestRun.id == run_id))
            run = result_obj.scalar_one_or_none()

            if run:
                run.status        = "fail" if failed > 0 else ("warn" if warned > 2 else "pass")
                run.passed        = passed
                run.failed        = failed
                run.warned        = warned
                run.total_tests   = total
                run.score         = score
                run.duration_secs = duration
                run.completed_at  = datetime.utcnow()
                run.test_results  = results
                run.coverage_map  = coverage_map
                run.anomaly_detected = failed > 0

            await db.commit()
            logger.info(
                f"[{run_id}] Complete — {passed}/{total} passed, "
                f"{len(bugs_created)} bugs filed, score={score}"
            )

        except Exception as e:
            logger.exception(f"[{run_id}] Pipeline error: {e}")
            # Mark run as errored
            result_obj = await db.execute(select(TestRun).where(TestRun.id == run_id))
            run = result_obj.scalar_one_or_none()
            if run:
                run.status = "error"
                await db.commit()
