"""
app/ml/engine.py
────────────────
ML engine with three models:

1. BillingAnomalyDetector   – IsolationForest to detect unusual billing charges
2. DiscrepancyClassifier    – RandomForest to classify the TYPE of discrepancy
3. ReleaseConfidenceScorer  – Gradient Boosting to score 0-100 release confidence

All models are trained on synthetic data on first use, then persisted to disk.
Swap in your real billing CSV data using the train_on_real_data() methods.
"""
import numpy as np
import pandas as pd
import joblib
import logging
from pathlib import Path
from typing import Optional
from datetime import datetime

from sklearn.ensemble import IsolationForest, RandomForestClassifier, GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

from app.core.config import settings

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# 1.  Billing Anomaly Detector  (Unsupervised — IsolationForest)
# ─────────────────────────────────────────────────────────────────────────────
class BillingAnomalyDetector:
    """
    Detects anomalous billing charges using IsolationForest.
    
    Features used:
      - amount (actual charge)
      - discrepancy_pct ((actual - expected) / expected * 100)
      - day_of_month (some services charge on specific days)
      - service_encoded (one-hot-like integer per service name)
      - line_item_count
      - amount_zscore (z-score within the last 12 periods)
    """

    MODEL_PATH = Path(settings.billing_model_path)
    CONTAMINATION = 0.05   # expect ~5% of records to be anomalous

    def __init__(self):
        self.model: Optional[Pipeline] = None
        self.label_encoder = LabelEncoder()
        self._load_or_train()

    # ── internal helpers ──────────────────────────────────────────────────────
    def _feature_vector(self, df: pd.DataFrame) -> np.ndarray:
        """Convert raw billing DataFrame into numeric features."""
        df = df.copy()
        df["discrepancy_pct"] = (
            (df["actual_amount"] - df["expected_amount"])
            / df["expected_amount"].replace(0, 1)
        ) * 100
        df["line_item_count"] = df.get("line_item_count", 1).fillna(1)
        df["day_of_month"] = df.get("day_of_month", 15).fillna(15)

        # Encode service names
        try:
            df["service_encoded"] = self.label_encoder.transform(df["service_name"])
        except Exception:
            df["service_encoded"] = 0

        return df[[
            "actual_amount",
            "expected_amount",
            "discrepancy_pct",
            "service_encoded",
            "line_item_count",
            "day_of_month",
        ]].values.astype(float)

    def _generate_synthetic_data(self, n_normal=1000, n_anomalous=50) -> pd.DataFrame:
        """
        Synthetic billing data for initial model training.
        Replace/augment with your real billing CSVs.
        """
        rng = np.random.default_rng(42)
        services = ["AWS", "GitHub", "CDN", "ELK", "NAS", "Azure", "Datadog"]

        # Normal records — small random variation around expected
        normal = pd.DataFrame({
            "service_name":    rng.choice(services, n_normal),
            "expected_amount": rng.uniform(100, 5000, n_normal),
            "day_of_month":    rng.integers(1, 28, n_normal),
            "line_item_count": rng.integers(1, 20, n_normal),
        })
        normal["actual_amount"] = (
            normal["expected_amount"] * rng.uniform(0.95, 1.05, n_normal)
        )
        normal["label"] = 0

        # Anomalous records — significant over/under charges
        anom = pd.DataFrame({
            "service_name":    rng.choice(services, n_anomalous),
            "expected_amount": rng.uniform(100, 5000, n_anomalous),
            "day_of_month":    rng.integers(1, 28, n_anomalous),
            "line_item_count": rng.integers(1, 20, n_anomalous),
        })
        # Anomalies: charges 30-300% above expected, or negative (credit errors)
        multipliers = rng.choice(
            [rng.uniform(1.3, 4.0, n_anomalous // 2),
             rng.uniform(-0.5, 0.3, n_anomalous // 2)],
            axis=0
        ).flatten()[:n_anomalous]
        anom["actual_amount"] = anom["expected_amount"] * multipliers
        anom["label"] = 1

        return pd.concat([normal, anom], ignore_index=True)

    def _train(self):
        """Train IsolationForest on synthetic (or real) billing data."""
        logger.info("Training BillingAnomalyDetector...")
        df = self._generate_synthetic_data()

        # Fit label encoder on all service names
        self.label_encoder.fit(df["service_name"])

        X = self._feature_vector(df)

        self.model = Pipeline([
            ("scaler", StandardScaler()),
            ("iso",    IsolationForest(
                n_estimators=200,
                contamination=self.CONTAMINATION,
                max_samples="auto",
                random_state=42,
            )),
        ])
        self.model.fit(X)
        self._save()
        logger.info("BillingAnomalyDetector trained and saved.")

    def _save(self):
        self.MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump({"model": self.model, "le": self.label_encoder}, self.MODEL_PATH)

    def _load_or_train(self):
        if self.MODEL_PATH.exists():
            try:
                obj = joblib.load(self.MODEL_PATH)
                self.model = obj["model"]
                self.label_encoder = obj["le"]
                logger.info("BillingAnomalyDetector loaded from disk.")
                return
            except Exception as e:
                logger.warning(f"Could not load billing model: {e}. Retraining.")
        self._train()

    # ── public API ────────────────────────────────────────────────────────────
    def predict(self, records: list[dict]) -> list[dict]:
        """
        Accepts a list of billing record dicts.
        Returns enriched dicts with:
          - is_anomaly (bool)
          - anomaly_score (float 0-1)
          - discrepancy_amount (float)
          - discrepancy_pct (float)
        """
        df = pd.DataFrame(records)

        # Ensure service names the encoder knows about
        known = set(self.label_encoder.classes_)
        df["service_name"] = df["service_name"].apply(
            lambda s: s if s in known else self.label_encoder.classes_[0]
        )

        X = self._feature_vector(df)
        preds   = self.model.predict(X)        # 1 = normal, -1 = anomaly
        scores  = self.model.decision_function(X)  # higher = more normal

        # Normalise score to 0-1 (1 = most anomalous)
        norm_scores = 1 - (scores - scores.min()) / (scores.ptp() + 1e-9)

        results = []
        for i, rec in enumerate(records):
            disc = rec["actual_amount"] - rec["expected_amount"]
            disc_pct = (disc / rec["expected_amount"] * 100) if rec["expected_amount"] else 0.0
            results.append({
                **rec,
                "is_anomaly":        bool(preds[i] == -1),
                "anomaly_score":     float(round(norm_scores[i], 4)),
                "discrepancy_amount": float(round(disc, 2)),
                "discrepancy_pct":   float(round(disc_pct, 2)),
            })
        return results

    def train_on_real_data(self, csv_path: str):
        """
        Fine-tune on your own billing CSV.
        CSV must have columns: service_name, expected_amount, actual_amount,
                               day_of_month, line_item_count
        """
        df = pd.read_csv(csv_path)
        self.label_encoder.fit(df["service_name"])
        X = self._feature_vector(df)
        self.model.fit(X)
        self._save()
        logger.info(f"BillingAnomalyDetector retrained on {csv_path}")


# ─────────────────────────────────────────────────────────────────────────────
# 2.  Discrepancy Classifier  (Supervised — RandomForest)
# ─────────────────────────────────────────────────────────────────────────────
class DiscrepancyClassifier:
    """
    Classifies the TYPE of billing anomaly:
      - overcharge      : actual > expected by >10%
      - undercharge     : actual < expected by >10% (potential credit error)
      - duplicate       : two identical charges in same period
      - spike           : sudden one-off charge much higher than historical avg
      - currency_error  : charge recorded in wrong currency (amount off by FX rate)
      - normal          : no meaningful discrepancy
    """

    LABELS = ["normal", "overcharge", "undercharge", "spike", "duplicate", "currency_error"]
    MODEL_PATH = Path(settings.discrepancy_model_path)

    def __init__(self):
        self.model: Optional[Pipeline] = None
        self.label_encoder = LabelEncoder()
        self._load_or_train()

    def _generate_synthetic_data(self, n=2000) -> pd.DataFrame:
        rng = np.random.default_rng(99)
        labels = rng.choice(self.LABELS, n, p=[0.55, 0.15, 0.10, 0.10, 0.05, 0.05])

        rows = []
        for label in labels:
            expected = rng.uniform(100, 5000)
            if label == "normal":
                actual = expected * rng.uniform(0.97, 1.03)
            elif label == "overcharge":
                actual = expected * rng.uniform(1.15, 3.0)
            elif label == "undercharge":
                actual = expected * rng.uniform(0.1, 0.85)
            elif label == "spike":
                actual = expected * rng.uniform(3.0, 10.0)
            elif label == "duplicate":
                actual = expected * 2.0 * rng.uniform(0.99, 1.01)
            elif label == "currency_error":
                # FX rates: ~1.08 EUR/USD, ~0.79 GBP/USD, ~1.36 USD/CAD
                actual = expected * rng.choice([1.08, 0.79, 1.36, 0.93])
            rows.append({
                "expected_amount":   expected,
                "actual_amount":     actual,
                "discrepancy_pct":   (actual - expected) / expected * 100,
                "discrepancy_abs":   abs(actual - expected),
                "line_item_count":   rng.integers(1, 20),
                "day_of_month":      rng.integers(1, 28),
                "label":             label,
            })
        return pd.DataFrame(rows)

    def _features(self, df: pd.DataFrame) -> np.ndarray:
        return df[[
            "expected_amount", "actual_amount", "discrepancy_pct",
            "discrepancy_abs", "line_item_count", "day_of_month",
        ]].fillna(0).values.astype(float)

    def _train(self):
        logger.info("Training DiscrepancyClassifier...")
        df = self._generate_synthetic_data()
        X = self._features(df)
        y = self.label_encoder.fit_transform(df["label"])

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        self.model = Pipeline([
            ("scaler", StandardScaler()),
            ("clf",    RandomForestClassifier(
                n_estimators=300,
                max_depth=12,
                class_weight="balanced",
                random_state=42,
                n_jobs=-1,
            )),
        ])
        self.model.fit(X_train, y_train)

        report = classification_report(
            y_test, self.model.predict(X_test),
            target_names=self.label_encoder.classes_,
        )
        logger.info(f"DiscrepancyClassifier report:\n{report}")
        self._save()

    def _save(self):
        self.MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump({"model": self.model, "le": self.label_encoder}, self.MODEL_PATH)

    def _load_or_train(self):
        if self.MODEL_PATH.exists():
            try:
                obj = joblib.load(self.MODEL_PATH)
                self.model = obj["model"]
                self.label_encoder = obj["le"]
                logger.info("DiscrepancyClassifier loaded from disk.")
                return
            except Exception as e:
                logger.warning(f"Could not load discrepancy model: {e}. Retraining.")
        self._train()

    def predict(self, records: list[dict]) -> list[str]:
        """Returns list of anomaly type labels, one per record."""
        rows = []
        for r in records:
            disc = r["actual_amount"] - r["expected_amount"]
            disc_pct = disc / r["expected_amount"] * 100 if r["expected_amount"] else 0
            rows.append({
                "expected_amount": r["expected_amount"],
                "actual_amount":   r["actual_amount"],
                "discrepancy_pct": disc_pct,
                "discrepancy_abs": abs(disc),
                "line_item_count": r.get("line_item_count", 1),
                "day_of_month":    r.get("day_of_month", 15),
            })
        df = pd.DataFrame(rows)
        X = self._features(df)
        preds = self.model.predict(X)
        return list(self.label_encoder.inverse_transform(preds))

    def predict_proba(self, record: dict) -> dict[str, float]:
        """Returns probability of each anomaly type for a single record."""
        disc = record["actual_amount"] - record["expected_amount"]
        disc_pct = disc / record["expected_amount"] * 100 if record["expected_amount"] else 0
        X = np.array([[
            record["expected_amount"], record["actual_amount"],
            disc_pct, abs(disc),
            record.get("line_item_count", 1),
            record.get("day_of_month", 15),
        ]])
        proba = self.model.predict_proba(X)[0]
        return dict(zip(self.label_encoder.classes_, proba.round(4)))


# ─────────────────────────────────────────────────────────────────────────────
# 3.  Release Confidence Scorer  (Supervised — GradientBoosting)
# ─────────────────────────────────────────────────────────────────────────────
class ReleaseConfidenceScorer:
    """
    Scores a test run 0-100 on release readiness.

    Features:
      - pass_rate         (passed / total)
      - fail_rate         (failed / total)
      - warn_rate         (warned / total)
      - critical_failures (count of severity=critical bugs)
      - coverage_score    (fraction of routes covered by tests)
      - duration_ratio    (run duration vs historical avg)
      - historical_pass_rate  (project's past pass rate)
    """

    MODEL_PATH = Path(settings.model_dir) / "confidence_model.pkl"

    def __init__(self):
        self.model: Optional[Pipeline] = None
        self._load_or_train()

    def _generate_synthetic_data(self, n=3000):
        rng = np.random.default_rng(7)
        rows = []
        for _ in range(n):
            total = rng.integers(10, 200)
            failed = rng.integers(0, int(total * 0.3))
            warned = rng.integers(0, int(total * 0.2))
            passed = total - failed - warned
            crit   = rng.integers(0, min(failed + 1, 5))
            cov    = rng.uniform(0.3, 1.0)
            dur    = rng.uniform(0.5, 2.5)
            hist   = rng.uniform(0.7, 1.0)

            # Score formula: 100 minus penalties
            score = 100
            score -= (failed / total) * 50
            score -= crit * 8
            score -= (warned / total) * 10
            score -= (1 - cov) * 15
            score -= max(0, dur - 1.5) * 5
            score = int(np.clip(score + rng.normal(0, 3), 0, 100))

            rows.append({
                "pass_rate":           passed / total,
                "fail_rate":           failed / total,
                "warn_rate":           warned / total,
                "critical_failures":   crit,
                "coverage_score":      cov,
                "duration_ratio":      dur,
                "historical_pass_rate": hist,
                "score":               score,
            })
        return pd.DataFrame(rows)

    def _features(self, df: pd.DataFrame) -> np.ndarray:
        return df[[
            "pass_rate", "fail_rate", "warn_rate",
            "critical_failures", "coverage_score",
            "duration_ratio", "historical_pass_rate",
        ]].fillna(0).values.astype(float)

    def _train(self):
        logger.info("Training ReleaseConfidenceScorer...")
        df = self._generate_synthetic_data()
        X = self._features(df)
        y = df["score"].values

        self.model = Pipeline([
            ("scaler", StandardScaler()),
            ("gbr",    GradientBoostingClassifier(
                n_estimators=200,
                max_depth=5,
                learning_rate=0.05,
                subsample=0.8,
                random_state=42,
            )),
        ])
        # Bin scores into classes for classifier
        y_binned = pd.cut(y, bins=[0, 40, 60, 75, 88, 100], labels=[0, 1, 2, 3, 4]).astype(int)
        self.model.fit(X, y_binned)
        self._save()
        logger.info("ReleaseConfidenceScorer trained.")

    def _save(self):
        self.MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(self.model, self.MODEL_PATH)

    def _load_or_train(self):
        if self.MODEL_PATH.exists():
            try:
                self.model = joblib.load(self.MODEL_PATH)
                logger.info("ReleaseConfidenceScorer loaded from disk.")
                return
            except Exception as e:
                logger.warning(f"Could not load confidence model: {e}. Retraining.")
        self._train()

    def score(
        self,
        passed: int, failed: int, warned: int, total: int,
        critical_failures: int = 0,
        coverage_score: float = 0.8,
        duration_ratio: float = 1.0,
        historical_pass_rate: float = 0.9,
    ) -> int:
        """Returns integer 0-100 release confidence score."""
        total = max(total, 1)
        X = np.array([[
            passed / total,
            failed / total,
            warned / total,
            critical_failures,
            coverage_score,
            duration_ratio,
            historical_pass_rate,
        ]])
        bin_pred = self.model.predict(X)[0]
        # Map bins back to midpoint scores
        score = {0: 20, 1: 50, 2: 67, 3: 81, 4: 94}.get(int(bin_pred), 70)

        # Fine-tune with a rule-based adjustment on top of ML bucket
        score -= failed * 2
        score -= critical_failures * 5
        score = int(np.clip(score, 0, 100))
        return score


# ─────────────────────────────────────────────────────────────────────────────
# Singleton instances  (imported by API routes)
# ─────────────────────────────────────────────────────────────────────────────
_anomaly_detector: Optional[BillingAnomalyDetector] = None
_discrepancy_clf:  Optional[DiscrepancyClassifier]  = None
_confidence_scorer: Optional[ReleaseConfidenceScorer] = None


def get_anomaly_detector() -> BillingAnomalyDetector:
    global _anomaly_detector
    if _anomaly_detector is None:
        _anomaly_detector = BillingAnomalyDetector()
    return _anomaly_detector


def get_discrepancy_classifier() -> DiscrepancyClassifier:
    global _discrepancy_clf
    if _discrepancy_clf is None:
        _discrepancy_clf = DiscrepancyClassifier()
    return _discrepancy_clf


def get_confidence_scorer() -> ReleaseConfidenceScorer:
    global _confidence_scorer
    if _confidence_scorer is None:
        _confidence_scorer = ReleaseConfidenceScorer()
    return _confidence_scorer


def explain_billing_anomaly(record: dict, anomaly_type: str, discrepancy_pct: float) -> str:
    """Generate a plain-English explanation of a billing anomaly."""
    service = record.get("service_name", "Unknown service")
    actual  = record.get("actual_amount", 0)
    expected = record.get("expected_amount", 0)
    period  = record.get("billing_period", "this period")
    disc    = abs(actual - expected)

    explanations = {
        "overcharge": (
            f"{service} charged ${actual:,.2f} for {period}, which is "
            f"${disc:,.2f} ({abs(discrepancy_pct):.1f}%) above the expected ${expected:,.2f}. "
            "This may indicate a pricing tier change, unexpected usage spike, or billing error. "
            "Recommend reviewing usage logs and contacting vendor support."
        ),
        "undercharge": (
            f"{service} charged ${actual:,.2f} for {period}, which is "
            f"${disc:,.2f} ({abs(discrepancy_pct):.1f}%) below the expected ${expected:,.2f}. "
            "This could be a credit applied in error, a partial invoice, or a missed charge "
            "that may appear in the next billing cycle."
        ),
        "spike": (
            f"{service} shows an unusual one-off charge of ${actual:,.2f} for {period}. "
            f"This is {discrepancy_pct:.0f}% above expected — a spike not seen in historical data. "
            "Likely causes: accidental resource scaling, data transfer overage, or API abuse."
        ),
        "duplicate": (
            f"{service} may have a duplicate charge of ${actual:,.2f} for {period}. "
            f"The amount is approximately 2× the expected ${expected:,.2f}. "
            "Check for duplicate invoice IDs or double-provisioned resources."
        ),
        "currency_error": (
            f"{service} charge of ${actual:,.2f} for {period} appears to have a currency mismatch. "
            f"Expected ${expected:,.2f} — the difference matches a common FX conversion rate. "
            "Verify the invoice currency matches your account's billing currency."
        ),
        "normal": (
            f"{service} charge of ${actual:,.2f} for {period} is within normal range "
            f"(expected ${expected:,.2f}, {abs(discrepancy_pct):.1f}% variance)."
        ),
    }
    return explanations.get(anomaly_type, "Anomaly detected — manual review recommended.")
