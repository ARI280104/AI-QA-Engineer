"""
app/api/webhook.py
──────────────────
GitHub Actions webhook → triggers a QABot test run.
"""
import uuid
import logging
from datetime import datetime
from fastapi import APIRouter, Header, HTTPException, BackgroundTasks, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.schemas import WebhookPayload, RunTriggerResponse
from app.core.models import TestRun, Project
from app.core.database import get_db
from app.core.config import settings
from app.services.runner import run_tests_background

router = APIRouter(prefix="/webhook", tags=["Webhook"])
logger = logging.getLogger(__name__)


async def verify_api_key(x_qabot_key: str = Header(...)):
    if x_qabot_key != settings.demo_api_key:
        raise HTTPException(status_code=401, detail="Invalid API key")
    return x_qabot_key


@router.post("/run", response_model=RunTriggerResponse)
async def trigger_run(
    payload: WebhookPayload,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    Called by GitHub Actions on every push.
    Creates a pending run record, then starts the test pipeline in background.
    """
    # Look up project by repo name
    result = await db.execute(
        select(Project).where(Project.name == payload.repo)
    )
    project = result.scalar_one_or_none()

    # Auto-create project if not found (demo / first-run behaviour)
    if not project:
        project = Project(
            id=str(uuid.uuid4()),
            name=payload.repo,
            repo_url=f"github.com/{payload.owner}/{payload.repo}",
            staging_url="https://staging.example.com",
            api_key=settings.demo_api_key,
        )
        db.add(project)
        await db.flush()

    run_id = f"run_{uuid.uuid4().hex[:8]}"
    branch = payload.ref.replace("refs/heads/", "") if payload.ref else "main"

    run = TestRun(
        id=run_id,
        project_id=project.id,
        commit_sha=payload.sha[:7] if payload.sha else "unknown",
        commit_message=payload.commit_message or "No commit message",
        branch=branch,
        status="running",
        triggered_at=datetime.utcnow(),
    )
    db.add(run)
    await db.commit()

    # Fire background task — crawl + test + ML score
    background_tasks.add_task(
        run_tests_background,
        run_id=run_id,
        project_id=project.id,
        staging_url=project.staging_url,
    )

    logger.info(f"Run {run_id} triggered for {payload.repo}@{branch}")
    return RunTriggerResponse(
        run_id=run_id,
        status="running",
        message=f"Test run {run_id} started for commit {payload.sha[:7] if payload.sha else 'unknown'}",
    )
