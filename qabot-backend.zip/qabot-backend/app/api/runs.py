"""
app/api/runs.py
───────────────
CRUD endpoints for test runs.
"""
import logging
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from typing import List, Optional

from app.core.database import get_db
from app.core.models import TestRun
from app.core.schemas import TestRunOut

router = APIRouter(prefix="/api/runs", tags=["Runs"])
logger = logging.getLogger(__name__)


@router.get("", response_model=List[TestRunOut])
async def list_runs(
    project_id: Optional[str] = Query(None),
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db),
):
    """List all test runs, newest first. Filter by project_id optionally."""
    q = select(TestRun).order_by(desc(TestRun.triggered_at)).limit(limit).offset(offset)
    if project_id:
        q = q.where(TestRun.project_id == project_id)
    result = await db.execute(q)
    return result.scalars().all()


@router.get("/{run_id}", response_model=TestRunOut)
async def get_run(run_id: str, db: AsyncSession = Depends(get_db)):
    """Get a single run by ID."""
    result = await db.execute(select(TestRun).where(TestRun.id == run_id))
    run = result.scalar_one_or_none()
    if not run:
        raise HTTPException(status_code=404, detail=f"Run {run_id} not found")
    return run


@router.get("/{run_id}/status")
async def run_status(run_id: str, db: AsyncSession = Depends(get_db)):
    """Lightweight status poll — used by frontend for live progress."""
    result = await db.execute(select(TestRun).where(TestRun.id == run_id))
    run = result.scalar_one_or_none()
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    return {
        "run_id":   run.id,
        "status":   run.status,
        "passed":   run.passed,
        "failed":   run.failed,
        "warned":   run.warned,
        "total":    run.total_tests,
        "score":    run.score,
        "duration": run.duration_secs,
    }
