"""
app/api/ml.py
─────────────
ML model management endpoints — retrain, status, feature importance.
"""
import logging
from fastapi import APIRouter, UploadFile, File, HTTPException
from pathlib import Path
import tempfile

from app.ml.engine import (
    get_anomaly_detector,
    get_discrepancy_classifier,
    get_confidence_scorer,
)
from app.core.config import settings

router = APIRouter(prefix="/api/ml", tags=["ML"])
logger = logging.getLogger(__name__)


@router.get("/status")
async def ml_status():
    """Check which ML models are loaded and ready."""
    return {
        "billing_anomaly_detector": {
            "loaded": Path(settings.billing_model_path).exists(),
            "path":   settings.billing_model_path,
            "algorithm": "IsolationForest",
            "purpose": "Detects unusual billing charges (unsupervised)",
        },
        "discrepancy_classifier": {
            "loaded": Path(settings.discrepancy_model_path).exists(),
            "path":   settings.discrepancy_model_path,
            "algorithm": "RandomForest",
            "purpose": "Classifies anomaly type: overcharge / spike / duplicate / currency_error",
        },
        "confidence_scorer": {
            "loaded": (Path(settings.model_dir) / "confidence_model.pkl").exists(),
            "path":   str(Path(settings.model_dir) / "confidence_model.pkl"),
            "algorithm": "GradientBoosting",
            "purpose": "Scores 0-100 release confidence from test run metrics",
        },
    }


@router.post("/retrain/billing")
async def retrain_billing_models():
    """Retrain billing ML models on current synthetic data (or uploaded real data)."""
    try:
        detector   = get_anomaly_detector()
        classifier = get_discrepancy_classifier()
        detector._train()
        classifier._train()
        return {"message": "Billing models retrained successfully."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Retraining failed: {e}")


@router.post("/retrain/billing/upload")
async def retrain_with_real_data(file: UploadFile = File(...)):
    """
    Upload your own billing CSV to fine-tune the anomaly detector.

    Required columns: service_name, expected_amount, actual_amount,
                      day_of_month, line_item_count
    """
    if not file.filename.endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only CSV files supported.")
    contents = await file.read()
    with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as tmp:
        tmp.write(contents)
        tmp_path = tmp.name
    try:
        detector = get_anomaly_detector()
        detector.train_on_real_data(tmp_path)
        return {"message": f"Model retrained on {file.filename}. {len(contents)} bytes processed."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Training failed: {e}")


@router.post("/retrain/confidence")
async def retrain_confidence_scorer():
    """Retrain the release confidence scorer."""
    try:
        scorer = get_confidence_scorer()
        scorer._train()
        return {"message": "Confidence scorer retrained successfully."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Retraining failed: {e}")


@router.get("/feature-importance")
async def feature_importance():
    """Return feature importances for the discrepancy classifier (RandomForest)."""
    clf = get_discrepancy_classifier()
    rf  = clf.model.named_steps["clf"]
    features = [
        "expected_amount", "actual_amount", "discrepancy_pct",
        "discrepancy_abs", "line_item_count", "day_of_month",
    ]
    importances = rf.feature_importances_.tolist()
    return {
        "model": "DiscrepancyClassifier (RandomForest)",
        "features": [
            {"name": f, "importance": round(imp, 4)}
            for f, imp in sorted(zip(features, importances), key=lambda x: -x[1])
        ],
    }
