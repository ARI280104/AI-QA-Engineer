"""
app/api/projects.py
───────────────────
Project management + dashboard stats endpoint.
"""
import uuid
import logging
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc, func
from typing import List

from app.core.database import get_db
from app.core.models import Project, TestRun, Bug, BillingRecord
from app.core.schemas import ProjectCreate, ProjectOut, DashboardStats
from app.core.config import settings

router = APIRouter(prefix="/api/projects", tags=["Projects"])
logger = logging.getLogger(__name__)


@router.post("", response_model=ProjectOut)
async def create_project(payload: ProjectCreate, db: AsyncSession = Depends(get_db)):
    project = Project(
        id=str(uuid.uuid4()),
        name=payload.name,
        repo_url=str(payload.repo_url),
        staging_url=str(payload.staging_url),
        api_key=f"qab_live_{uuid.uuid4().hex[:16]}",
    )
    db.add(project)
    await db.commit()
    await db.refresh(project)
    return project


@router.get("", response_model=List[ProjectOut])
async def list_projects(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Project).where(Project.is_active == True))
    return result.scalars().all()


@router.get("/{project_id}", response_model=ProjectOut)
async def get_project(project_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Project).where(Project.id == project_id))
    p = result.scalar_one_or_none()
    if not p:
        raise HTTPException(status_code=404, detail="Project not found")
    return p


@router.get("/{project_id}/dashboard", response_model=DashboardStats)
async def dashboard_stats(project_id: str, db: AsyncSession = Depends(get_db)):
    """Aggregated stats for the dashboard page."""

    # Runs
    runs_result = await db.execute(
        select(TestRun)
        .where(TestRun.project_id == project_id)
        .order_by(desc(TestRun.triggered_at))
        .limit(20)
    )
    runs = runs_result.scalars().all()
    total_runs     = len(runs)
    latest_score   = runs[0].score if runs else 0
    avg_duration   = sum(r.duration_secs for r in runs) / max(total_runs, 1)

    # Open bugs
    bugs_result = await db.execute(
        select(Bug).where(Bug.project_id == project_id, Bug.status == "open")
    )
    open_bugs = len(bugs_result.scalars().all())

    # Billing anomalies
    billing_result = await db.execute(
        select(BillingRecord).where(
            BillingRecord.project_id == project_id,
            BillingRecord.is_anomaly == True,
            BillingRecord.status == "open",
        )
    )
    billing_records = billing_result.scalars().all()
    billing_anomalies  = len(billing_records)
    total_discrepancy  = sum(abs(r.discrepancy_amount) for r in billing_records)

    return DashboardStats(
        total_runs=total_runs,
        open_bugs=open_bugs,
        latest_score=latest_score,
        avg_duration_secs=round(avg_duration, 1),
        billing_anomalies=billing_anomalies,
        total_discrepancy=round(total_discrepancy, 2),
    )
