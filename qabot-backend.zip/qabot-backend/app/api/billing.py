"""
app/api/billing.py
──────────────────
Billing verification endpoints with ML anomaly detection.
"""
import uuid
import logging
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, File
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from typing import List, Optional
import pandas as pd
import io

from app.core.database import get_db
from app.core.models import BillingRecord
from app.core.schemas import (
    BillingRecordCreate, BillingRecordOut,
    BillingAnalysisRequest, BillingAnalysisResponse,
)
from app.ml.engine import (
    get_anomaly_detector,
    get_discrepancy_classifier,
    explain_billing_anomaly,
)

router = APIRouter(prefix="/api/billing", tags=["Billing"])
logger = logging.getLogger(__name__)


# ─── Helper: run ML on a list of record dicts ─────────────────────────────────
def _run_ml_analysis(records_data: list[dict]) -> list[dict]:
    """
    Runs anomaly detection + discrepancy classification on raw record dicts.
    Returns enriched dicts with ML fields added.
    """
    detector   = get_anomaly_detector()
    classifier = get_discrepancy_classifier()

    enriched   = detector.predict(records_data)          # adds is_anomaly, anomaly_score, discrepancy_*
    anom_types = classifier.predict(records_data)        # adds anomaly_type label

    for i, rec in enumerate(enriched):
        atype = anom_types[i]
        # If detector says normal but classifier says anomaly type, trust detector
        if not rec["is_anomaly"]:
            atype = "normal"
        rec["anomaly_type"]   = atype
        rec["ml_explanation"] = explain_billing_anomaly(
            rec, atype, rec.get("discrepancy_pct", 0)
        )
    return enriched


# ─── Routes ───────────────────────────────────────────────────────────────────

@router.post("/analyze", response_model=BillingAnalysisResponse)
async def analyze_billing(
    payload: BillingAnalysisRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Submit one or more billing records for ML analysis.
    Returns anomaly flags, types, scores, and plain-English explanations.
    Persists results to DB.
    """
    raw = [r.model_dump() for r in payload.records]
    enriched = _run_ml_analysis(raw)

    saved_records = []
    for rec in enriched:
        line_items = rec.get("line_items", [])
        br = BillingRecord(
            id=str(uuid.uuid4()),
            project_id=rec["project_id"],
            service_name=rec["service_name"],
            account_id=rec.get("account_id"),
            billing_period=rec["billing_period"],
            expected_amount=rec["expected_amount"],
            actual_amount=rec["actual_amount"],
            currency=rec.get("currency", "USD"),
            line_items=[li if isinstance(li, dict) else li.model_dump() for li in line_items],
            is_anomaly=rec["is_anomaly"],
            anomaly_score=rec["anomaly_score"],
            anomaly_type=rec.get("anomaly_type"),
            discrepancy_amount=rec.get("discrepancy_amount", 0.0),
            ml_explanation=rec.get("ml_explanation"),
            created_at=datetime.utcnow(),
        )
        db.add(br)
        saved_records.append(br)

    await db.commit()

    anomalies = [r for r in saved_records if r.is_anomaly]
    total_disc = sum(abs(r.discrepancy_amount) for r in anomalies)
    summary = (
        f"Analyzed {len(saved_records)} billing records. "
        f"Found {len(anomalies)} anomalies with a total discrepancy of ${total_disc:,.2f}. "
        + (
            f"Most common issue: {max(set(r.anomaly_type for r in anomalies if r.anomaly_type), key=lambda t: sum(1 for r in anomalies if r.anomaly_type == t))}."
            if anomalies else "All records are within normal range."
        )
    )

    return BillingAnalysisResponse(
        total_records=len(saved_records),
        anomalies_found=len(anomalies),
        total_discrepancy=round(total_disc, 2),
        results=saved_records,
        summary=summary,
    )


@router.post("/upload-csv", response_model=BillingAnalysisResponse)
async def upload_billing_csv(
    file: UploadFile = File(...),
    project_id: str = Query(...),
    db: AsyncSession = Depends(get_db),
):
    """
    Upload a billing CSV for bulk ML analysis.

    Required CSV columns:
      service_name, expected_amount, actual_amount, billing_period
    Optional:
      account_id, currency, line_item_count, day_of_month
    """
    if not file.filename.endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only CSV files are supported.")

    contents = await file.read()
    try:
        df = pd.read_csv(io.BytesIO(contents))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not parse CSV: {e}")

    required = {"service_name", "expected_amount", "actual_amount", "billing_period"}
    missing = required - set(df.columns)
    if missing:
        raise HTTPException(
            status_code=400,
            detail=f"CSV missing required columns: {', '.join(missing)}"
        )

    df["project_id"] = project_id
    df["currency"]   = df.get("currency", "USD")
    records_data = df.to_dict("records")

    enriched = _run_ml_analysis(records_data)

    saved = []
    for rec in enriched:
        br = BillingRecord(
            id=str(uuid.uuid4()),
            project_id=project_id,
            service_name=str(rec["service_name"]),
            account_id=str(rec.get("account_id", "")),
            billing_period=str(rec["billing_period"]),
            expected_amount=float(rec["expected_amount"]),
            actual_amount=float(rec["actual_amount"]),
            currency=str(rec.get("currency", "USD")),
            line_items=[],
            is_anomaly=rec["is_anomaly"],
            anomaly_score=rec["anomaly_score"],
            anomaly_type=rec.get("anomaly_type"),
            discrepancy_amount=rec.get("discrepancy_amount", 0.0),
            ml_explanation=rec.get("ml_explanation"),
            created_at=datetime.utcnow(),
        )
        db.add(br)
        saved.append(br)

    await db.commit()
    anomalies  = [r for r in saved if r.is_anomaly]
    total_disc = sum(abs(r.discrepancy_amount) for r in anomalies)

    return BillingAnalysisResponse(
        total_records=len(saved),
        anomalies_found=len(anomalies),
        total_discrepancy=round(total_disc, 2),
        results=saved,
        summary=f"CSV processed: {len(saved)} records, {len(anomalies)} anomalies, ${total_disc:,.2f} total discrepancy.",
    )


@router.get("", response_model=List[BillingRecordOut])
async def list_billing_records(
    project_id: Optional[str] = Query(None),
    anomalies_only: bool = Query(False),
    service_name: Optional[str] = Query(None),
    billing_period: Optional[str] = Query(None),
    limit: int = Query(50, ge=1, le=500),
    db: AsyncSession = Depends(get_db),
):
    """List billing records with optional filters."""
    q = select(BillingRecord).order_by(desc(BillingRecord.created_at)).limit(limit)
    if project_id:     q = q.where(BillingRecord.project_id == project_id)
    if anomalies_only: q = q.where(BillingRecord.is_anomaly == True)
    if service_name:   q = q.where(BillingRecord.service_name == service_name)
    if billing_period: q = q.where(BillingRecord.billing_period == billing_period)
    result = await db.execute(q)
    return result.scalars().all()


@router.get("/summary")
async def billing_summary(
    project_id: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
):
    """Aggregated billing summary — total anomalies, discrepancy by service."""
    q = select(BillingRecord)
    if project_id:
        q = q.where(BillingRecord.project_id == project_id)
    result = await db.execute(q)
    records = result.scalars().all()

    by_service: dict = {}
    for r in records:
        svc = r.service_name
        if svc not in by_service:
            by_service[svc] = {"total": 0, "anomalies": 0, "discrepancy": 0.0}
        by_service[svc]["total"] += 1
        if r.is_anomaly:
            by_service[svc]["anomalies"] += 1
            by_service[svc]["discrepancy"] += abs(r.discrepancy_amount)

    anomalies     = [r for r in records if r.is_anomaly]
    total_disc    = sum(abs(r.discrepancy_amount) for r in anomalies)
    anom_types    = {}
    for r in anomalies:
        anom_types[r.anomaly_type] = anom_types.get(r.anomaly_type, 0) + 1

    return {
        "total_records":       len(records),
        "total_anomalies":     len(anomalies),
        "total_discrepancy":   round(total_disc, 2),
        "anomaly_breakdown":   anom_types,
        "by_service":          by_service,
    }


@router.get("/{record_id}", response_model=BillingRecordOut)
async def get_billing_record(record_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(BillingRecord).where(BillingRecord.id == record_id))
    rec = result.scalar_one_or_none()
    if not rec:
        raise HTTPException(status_code=404, detail="Billing record not found")
    return rec


@router.patch("/{record_id}/status")
async def update_billing_status(
    record_id: str,
    status: str = Query(..., pattern="^(open|resolved|disputed)$"),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(BillingRecord).where(BillingRecord.id == record_id))
    rec = result.scalar_one_or_none()
    if not rec:
        raise HTTPException(status_code=404, detail="Record not found")
    rec.status = status
    await db.commit()
    return {"id": record_id, "status": status}
