"""
app/api/bugs.py
───────────────
Bug report CRUD endpoints.
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from typing import List, Optional
from datetime import datetime

from app.core.database import get_db
from app.core.models import Bug
from app.core.schemas import BugOut, BugUpdate

router = APIRouter(prefix="/api/bugs", tags=["Bugs"])


@router.get("", response_model=List[BugOut])
async def list_bugs(
    project_id: Optional[str] = Query(None),
    run_id: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    severity: Optional[str] = Query(None),
    limit: int = Query(50, ge=1, le=200),
    db: AsyncSession = Depends(get_db),
):
    q = select(Bug).order_by(desc(Bug.created_at)).limit(limit)
    if project_id: q = q.where(Bug.project_id == project_id)
    if run_id:     q = q.where(Bug.run_id == run_id)
    if status:     q = q.where(Bug.status == status)
    if severity:   q = q.where(Bug.severity == severity)
    result = await db.execute(q)
    return result.scalars().all()


@router.get("/{bug_id}", response_model=BugOut)
async def get_bug(bug_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Bug).where(Bug.id == bug_id))
    bug = result.scalar_one_or_none()
    if not bug:
        raise HTTPException(status_code=404, detail="Bug not found")
    return bug


@router.patch("/{bug_id}", response_model=BugOut)
async def update_bug(bug_id: str, update: BugUpdate, db: AsyncSession = Depends(get_db)):
    """Mark a bug as resolved or ignored."""
    result = await db.execute(select(Bug).where(Bug.id == bug_id))
    bug = result.scalar_one_or_none()
    if not bug:
        raise HTTPException(status_code=404, detail="Bug not found")
    bug.status = update.status.value
    if update.status.value == "resolved":
        bug.resolved_at = datetime.utcnow()
    await db.commit()
    await db.refresh(bug)
    return bug


@router.get("/summary/open-count")
async def open_bug_count(project_id: Optional[str] = Query(None), db: AsyncSession = Depends(get_db)):
    q = select(Bug).where(Bug.status == "open")
    if project_id:
        q = q.where(Bug.project_id == project_id)
    result = await db.execute(q)
    bugs = result.scalars().all()
    by_severity = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    for b in bugs:
        by_severity[b.severity] = by_severity.get(b.severity, 0) + 1
    return {"total": len(bugs), "by_severity": by_severity}
